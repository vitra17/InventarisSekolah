<?xml version="1.0" encoding="UTF-8"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <Worksheet ss:Name="Laporan Inventaris">
  <Table>
   <Row>
    <Cell><Data ss:Type="String">LAPORAN BARANG SD Muhammadiyah Metro Pusat</Data></Cell>
   </Row>
   <Row>
    <Cell><Data ss:Type="String">Ruang: <?php echo e($selectedLokasi->nama_ruangan ?? 'Semua Ruangan'); ?></Data></Cell>
   </Row>
   <Row>
    <Cell><Data ss:Type="String">Dicetak pada: <?php echo e(date('d-m-Y H:i:s')); ?></Data></Cell>
   </Row>
   <Row>
   </Row>
   <Row>
    <Cell><Data ss:Type="String">NO</Data></Cell>
    <Cell><Data ss:Type="String">KODE LOKASI</Data></Cell>
    <Cell><Data ss:Type="String">KODE ASET</Data></Cell>
    <Cell><Data ss:Type="String">KATEGORI</Data></Cell>
    <Cell><Data ss:Type="String">KELOMPOK</Data></Cell>
    <Cell><Data ss:Type="String">JENIS</Data></Cell>
    <Cell><Data ss:Type="String">NAMA</Data></Cell>
    <Cell><Data ss:Type="String">KONDISI</Data></Cell>
    <Cell><Data ss:Type="String">PEROLEHAN</Data></Cell>
    <Cell><Data ss:Type="String">HARGA</Data></Cell>
    <Cell><Data ss:Type="String">TAHUN</Data></Cell>
    <Cell><Data ss:Type="String">KET</Data></Cell>
   </Row>
   <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <Row>
    <Cell><Data ss:Type="Number"><?php echo e($index + 1); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->lokasi->kode_ruangan ?? '-'); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->kode_aset); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->masterKodeAset->kategori ?? $barang->kategori ?? '-'); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->masterKodeAset->kelompok ?? '-'); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->masterKodeAset->jenis ?? '-'); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->nama_barang); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->kondisi_terkini); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->sumber_perolehan ?? 'Beli'); ?></Data></Cell>
    <Cell><Data ss:Type="String">Rp <?php echo e(number_format($barang->harga_perolehan, 0, ',', '.')); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->tanggal_perolehan ? \Carbon\Carbon::parse($barang->tanggal_perolehan)->format('Y') : '-'); ?></Data></Cell>
    <Cell><Data ss:Type="String"><?php echo e($barang->catatan_waka ?? '-'); ?></Data></Cell>
   </Row>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </Table>
 </Worksheet>
</Workbook><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/barang/export_excel.blade.php ENDPATH**/ ?>