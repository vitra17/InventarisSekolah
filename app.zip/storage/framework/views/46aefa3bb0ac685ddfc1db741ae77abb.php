<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Validasi Penempatan Barang Baru</h2>

<?php if($barangs->isEmpty()): ?>
    <div class="alert alert-info">
        Tidak ada barang yang menunggu validasi.
    </div>
<?php else: ?>
    <div class="row">
        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100 border-warning">
                <div class="card-header bg-warning text-dark">
                    <strong>Pending:</strong> <?php echo e($barang->kode_aset); ?>

                </div>
                <div class="card-body">
                    <p><strong>Barang:</strong> <?php echo e($barang->nama_barang); ?> <?php echo e($barang->merek ? '- ' . $barang->merek : ''); ?></p>
                    <p><strong>Kategori:</strong> <?php echo e($barang->masterKodeAset->kategori ?? '-'); ?></p>
                    <p><strong>Harga:</strong> Rp <?php echo e(number_format($barang->harga_perolehan, 0, ',', '.')); ?></p>
                    <p><strong>Lokasi Awal (Staff):</strong> <?php echo e($barang->lokasi->nama_ruangan); ?></p>
                    
                    <hr>
                    
                    <form action="<?php echo e(route('barang.approve', $barang)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Tentukan Lokasi Final Penempatan:</label>
                            <select name="lokasi_id_final" class="form-select" required>
                                <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lokasi->id); ?>" <?php echo e($lokasi->id == $barang->lokasi_id ? 'selected' : ''); ?>>
                                        <?php echo e($lokasi->nama_ruangan); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Catatan untuk Staff (Opsional):</label>
                            <textarea name="catatan_waka" class="form-control" rows="2" placeholder="Misal: Pastikan kabel tertata rapi"></textarea>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-check-circle"></i> Validasi & Setujui Penempatan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/barang/pending_validation.blade.php ENDPATH**/ ?>