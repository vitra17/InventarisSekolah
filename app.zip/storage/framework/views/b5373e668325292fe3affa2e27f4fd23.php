<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header 
                <?php if(Auth::user()->role === 'waka'): ?> bg-primary text-white 
                <?php elseif(Auth::user()->role === 'penjaga' && $laporan->status_laporan === 'approved_waka'): ?> bg-success text-white
                <?php else: ?> bg-warning text-dark <?php endif; ?>">
                
                <?php if(Auth::user()->role === 'waka'): ?>
                    <h5 class="mb-0">Instruksi Tindak Lanjut (Waka)</h5>
                <?php elseif(Auth::user()->role === 'penjaga' && $laporan->status_laporan === 'approved_waka'): ?>
                    <h5 class="mb-0">Lapor Penyelesaian Perbaikan</h5>
                <?php else: ?>
                    <h5 class="mb-0">Revisi Laporan Kerusakan</h5>
                <?php endif; ?>
            </div>
            
            <div class="card-body">
                <?php if(Auth::user()->role === 'waka'): ?>
                <form action="<?php echo e(route('pemeliharaan.waka.instruksi.update', $laporan)); ?>" method="POST" enctype="multipart/form-data">
                <?php else: ?>
                <form action="<?php echo e(route('pemeliharaan.update', $laporan)); ?>" method="POST" enctype="multipart/form-data">
                <?php endif; ?>  
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    
                    <?php if(Auth::user()->role === 'penjaga' && in_array($laporan->status_laporan, ['draft', 'revisi'])): ?>
                        <div class="alert alert-warning">
                            <strong>Catatan:</strong> Mohon perbaiki deskripsi atau unggah ulang foto bukti yang lebih jelas.
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Deskripsi Kerusakan</label>
                            <textarea name="deskripsi_kerusakan" class="form-control" rows="4" required><?php echo e(old('deskripsi_kerusakan', $laporan->deskripsi_kerusakan)); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Upload Ulang Foto Bukti (Opsional jika tidak berubah)</label>
                            <input type="file" name="foto_bukti_awal" class="form-control" accept="image/*">
                            <?php if($laporan->foto_bukti_awal): ?>
                                <div class="mt-2">
                                    <small>Foto Saat Ini:</small><br>
                                    <img src="<?php echo e(asset('storage/' . $laporan->foto_bukti_awal)); ?>" style="max-height: 100px;" class="img-thumbnail">
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(Auth::user()->role === 'waka' && $laporan->status_laporan === 'validated_staff'): ?>
                        <div class="alert alert-info">
                            <strong>Info:</strong> Laporan ini telah divalidasi oleh Staff. Berikan instruksi perbaikan.
                        </div>

                        <?php
                            // Ambil dari database InstruksiPemeliharaan sesuai dengan MasterKodeAset barang
                            $presetOptions = [];
                            if ($laporan->barang && $laporan->barang->masterKodeAset) {
                                $presetOptions = $laporan->barang->masterKodeAset->instruksiPemeliharaans->pluck('instruksi');
                            }
                            
                            // Jika kosong di database, berikan opsi fallback umum
                            if ($presetOptions->isEmpty()) {
                                $presetOptions = collect([
                                    'Lakukan pengecekan fisik dan perbaikan ringan',
                                    'Ganti suku cadang yang rusak',
                                    'Bawa ke tempat servis rekanan',
                                ]);
                            }
                        ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Instruksi Tindak Lanjut (Pilihan Cepat)</label>
                            <select name="instruksi_cepat" class="form-select mb-2 <?php $__errorArgs = ['tindakan_waka'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">-- Pilih Instruksi Sesuai Jenis Barang --</option>
                                <?php $__currentLoopData = $presetOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($opt); ?>" <?php echo e(old('instruksi_cepat') == $opt ? 'selected' : ''); ?>><?php echo e($opt); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            
                            <label class="form-label fw-bold">Catatan Tambahan (Opsional)</label>
                            <textarea id="tindakanWaka" name="tindakan_waka" class="form-control <?php $__errorArgs = ['tindakan_waka'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" placeholder="Ketik instruksi tambahan di sini jika diperlukan..."><?php echo e(old('tindakan_waka')); ?></textarea>
                            <?php $__errorArgs = ['tindakan_waka'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="text-muted">Pilih instruksi dari pilihan cepat, atau isi catatan manual. Keduanya akan digabungkan jika diisi.</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Estimasi Biaya (Rp)</label>
                            <input type="number" name="biaya_estimasi" class="form-control" placeholder="0" value="<?php echo e(old('biaya_estimasi', $laporan->biaya_estimasi)); ?>">
                        </div>
                    <?php endif; ?>

                    
                    <?php if(Auth::user()->role === 'penjaga' && $laporan->status_laporan === 'approved_waka'): ?>
                        <div class="alert alert-success">
                            <strong>Instruksi Waka:</strong><br>
                            <em><?php echo e($laporan->tindakan_waka); ?></em>
                            <br><strong>Estimasi Biaya:</strong> Rp <?php echo e(number_format($laporan->biaya_estimasi ?? 0, 0, ',', '.')); ?>

                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Foto Bukti Setelah Perbaikan (Wajib)</label>
                            <input type="file" name="foto_bukti_akhir" class="form-control" accept="image/*" required>
                            <small class="text-muted">Ambil foto barang setelah diperbaiki sebagai bukti penyelesaian.</small>
                        </div>
                    <?php endif; ?>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                        <a href="<?php echo e(route('pemeliharaan.index')); ?>" class="btn btn-secondary me-md-2">Batal</a>
                        
                        <?php if(Auth::user()->role === 'penjaga' && in_array($laporan->status_laporan, ['draft', 'revisi'])): ?>
                            <button type="submit" class="btn btn-warning">Simpan Revisi</button>
                        <?php elseif(Auth::user()->role === 'waka'): ?>
                            <button type="submit" class="btn btn-primary">Setujui & Instruksikan</button>
                        <?php elseif(Auth::user()->role === 'penjaga' && $laporan->status_laporan === 'approved_waka'): ?>
                            <button type="submit" class="btn btn-success">Laporkan Selesai</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/pemeliharaan/edit.blade.php ENDPATH**/ ?>