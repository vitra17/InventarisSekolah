<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="fas fa-door-open me-2 text-primary-custom"></i>Manajemen Ruangan</h2>
    <?php if(in_array(Auth::user()->role, ['staff', 'waka'])): ?>
        <a href="<?php echo e(route('lokasi.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Tambah Ruangan Baru
        </a>
    <?php endif; ?>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Nama Ruangan</th>
                        <th>Kode Ruangan</th>
                        <th>Penanggung Jawab</th>
                        <th>Jumlah Barang</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><strong><?php echo e($lokasi->nama_ruangan); ?></strong></td>
                        <td><?php echo e($lokasi->kode_ruangan); ?></td>
                        <td><?php echo e($lokasi->penanggung_jawab ?? '-'); ?></td>
                        <td>
                            <span class="badge bg-info text-dark"><?php echo e($lokasi->barangs()->where('status_validasi', 'approved')->count()); ?> Item</span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('lokasi.show', $lokasi)); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye"></i> Lihat
                            </a>
                            
                            <?php if(in_array(Auth::user()->role, ['staff', 'waka'])): ?>
                                <a href="<?php echo e(route('lokasi.edit', $lokasi)); ?>" class="btn btn-sm btn-outline-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                
                                <!-- Hapus hanya jika tidak ada barang -->
                                <?php if($lokasi->barangs()->count() == 0): ?>
                                    <form action="<?php echo e(route('lokasi.destroy', $lokasi)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus ruangan ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-outline-secondary" disabled title="Masih ada barang di ruangan ini">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">Belum ada data ruangan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/lokasi/index.blade.php ENDPATH**/ ?>