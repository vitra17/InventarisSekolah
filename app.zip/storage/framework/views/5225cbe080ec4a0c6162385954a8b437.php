<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-danger">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0">Form Lapor Kerusakan Barang</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('pemeliharaan.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="mb-3">
                        <label class="form-label">Pilih Barang yang Rusak</label>
                        <select name="barang_id" class="form-select" required>
                            <option value="">-- Pilih Barang --</option>
                            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($barang->id); ?>"><?php echo e($barang->kode_aset); ?> - <?php echo e($barang->merek); ?> <?php echo e($barang->jenis); ?> (<?php echo e($barang->lokasi->nama_ruangan); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Deskripsi Kerusakan</label>
                        <textarea name="deskripsi_kerusakan" class="form-control" rows="4" placeholder="Jelaskan apa yang rusak, misalnya: Layar laptop retak, tidak bisa nyala, dll." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Foto Bukti Kerusakan (Wajib)</label>
                        <input type="file" name="foto_bukti_awal" class="form-control" accept="image/*" required>
                        <small class="text-muted">Format: JPG/PNG, Maksimal 2MB.</small>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?php echo e(route('pemeliharaan.index')); ?>" class="btn btn-secondary me-md-2">Batal</a>
                        <button type="submit" class="btn btn-danger">Kirim Laporan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/pemeliharaan/create.blade.php ENDPATH**/ ?>