<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0">Edit Data Barang: <?php echo e($barang->kode_aset); ?></h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('barang.update', $barang)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    
                    <div class="mb-3">
                        <label class="form-label">Kategori / Master Kode Aset</label>
                        <select name="master_kode_aset_id" class="form-select" required>
                            <option value="">Pilih Kategori / Master Kode</option>
                            <?php $__currentLoopData = $masterKodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mk->id); ?>" data-prefix="<?php echo e($mk->kode_prefix); ?>" data-next="<?php echo e($mk->next_sequence); ?>" <?php echo e($barang->master_kode_aset_id == $mk->id ? 'selected' : ''); ?>>
                                    <?php echo e($mk->kode_prefix); ?> - <?php echo e($mk->keterangan); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['master_kode_aset_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Kode Aset Saat Ini / Preview</label>
                        <input type="text" class="form-control" id="kode-preview-input" value="<?php echo e($barang->kode_aset); ?>" disabled>
                        <small class="text-muted" id="kode-preview-info">*Jika Anda mengubah <strong>Kategori / Master Kode Aset</strong> di atas, sistem akan <strong>otomatis</strong> membuatkan nomor aset baru sesuai urutan kategori tersebut saat data disimpan.</small>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Perolehan</label>
                            <input type="date" name="tanggal_perolehan" class="form-control" value="<?php echo e(\Carbon\Carbon::parse($barang->tanggal_perolehan)->format('Y-m-d')); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Lokasi Penempatan Sementara</label>
                            <select name="lokasi_id" class="form-select" required>
                                <option value="">Pilih Lokasi Awal</option>
                                <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lokasi->id); ?>" <?php echo e($barang->lokasi_id == $lokasi->id ? 'selected' : ''); ?>><?php echo e($lokasi->nama_ruangan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Barang</label>
                            <input type="text" name="nama_barang" class="form-control" value="<?php echo e(old('nama_barang', $barang->nama_barang)); ?>" placeholder="Contoh: Kursi Guru, Laptop Asus" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Merek (Opsional)</label>
                            <input type="text" name="merek" class="form-control" value="<?php echo e(old('merek', $barang->merek)); ?>" placeholder="Contoh: Asus, Olympic, dll">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Harga Perolehan (Rp)</label>
                            <input type="number" name="harga_perolehan" class="form-control" value="<?php echo e(old('harga_perolehan', $barang->harga_perolehan)); ?>" placeholder="0" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kondisi Saat Ini</label>
                            <select name="kondisi_terkini" class="form-select" required>
                                <option value="Baik" <?php echo e($barang->kondisi_terkini == 'Baik' ? 'selected' : ''); ?>>Baik</option>
                                <option value="Rusak Ringan" <?php echo e($barang->kondisi_terkini == 'Rusak Ringan' ? 'selected' : ''); ?>>Rusak Ringan</option>
                                <option value="Rusak Berat" <?php echo e($barang->kondisi_terkini == 'Rusak Berat' ? 'selected' : ''); ?>>Rusak Berat</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Sumber Dana (Contoh: BOS, Komite)</label>
                        <input type="text" name="sumber_dana" class="form-control" value="<?php echo e(old('sumber_dana', $barang->sumber_dana)); ?>" placeholder="Contoh: BOS, Komite">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Catatan Tambahan (Opsional)</label>
                        <textarea name="catatan_waka" class="form-control" rows="2"><?php echo e(old('catatan_waka', $barang->catatan_waka)); ?></textarea>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-secondary me-md-2">Batal</a>
                        <button type="submit" class="btn btn-warning">Perbarui Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const prefixSelect = document.querySelector('select[name="master_kode_aset_id"]');
        const previewInput = document.getElementById('kode-preview-input');
        const previewInfo = document.getElementById('kode-preview-info');
        const originalKode = "<?php echo e($barang->kode_aset); ?>";
        const originalMasterId = "<?php echo e($barang->master_kode_aset_id); ?>";

        function updatePreview() {
            const selectedOption = prefixSelect.options[prefixSelect.selectedIndex];
            const selectedValue = prefixSelect.value;
            const prefix = selectedOption ? selectedOption.getAttribute('data-prefix') : null;
            const nextSeq = selectedOption ? selectedOption.getAttribute('data-next') : null;
            
            if (selectedValue == originalMasterId) {
                previewInput.value = originalKode;
                previewInfo.innerHTML = "*Jika Anda mengubah <strong>Kategori / Master Kode Aset</strong> di atas, sistem akan <strong>otomatis</strong> membuatkan nomor aset baru sesuai urutan kategori tersebut saat data disimpan.";
                previewInput.style.backgroundColor = "";
            } else if (prefix && nextSeq) {
                previewInput.value = `${prefix}.${nextSeq}`;
                previewInfo.innerHTML = "<span class='text-danger fw-bold'><i class='fas fa-exclamation-triangle'></i> Perhatian: Kode aset akan otomatis diubah menjadi ini!</span>";
                previewInput.style.backgroundColor = "#fff3cd"; // warna peringatan kuning
            } else {
                previewInput.value = 'Pilih Kategori...';
            }
        }

        prefixSelect.addEventListener('change', updatePreview);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/barang/edit.blade.php ENDPATH**/ ?>