<?php $__env->startSection('content'); ?>
<style>
    /* Style Khusus Print */
    @media print {
        body * {
            visibility: hidden;
        }
        #area-cetak, #area-cetak * {
            visibility: visible;
        }
        #area-cetak {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }
        .no-print {
            display: none !important;
        }
        table {
            font-size: 10pt;
            width: 100%;
        }
        th, td {
            border: 1px solid black !important;
            padding: 4px;
        }
    }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 no-print">
    <h2>Laporan Riwayat Pemeliharaan Barang</h2>
    <button onclick="window.print()" class="btn btn-primary">
        <i class="fas fa-print"></i> Cetak / Simpan PDF
    </button>
</div>

<!-- Area yang akan dicetak -->
<div id="area-cetak">
    <div class="text-center mb-4">
        <h4>LAPORAN PEMELIHARAAN & PERBAIKAN BARANG</h4>
        <h5>SD MUHAMMADIYAH METRO PUSAT</h5>
        <p>Periode: 
            <?php if(request('tgl_mulai')): ?>
                <?php echo e(\Carbon\Carbon::parse(request('tgl_mulai'))->format('d F Y')); ?> s/d 
                <?php echo e(request('tgl_akhir') ? \Carbon\Carbon::parse(request('tgl_akhir'))->format('d F Y') : 'Sekarang'); ?>

            <?php else: ?>
                Semua Waktu
            <?php endif; ?>
        </p>
        <hr>
    </div>

    <!-- Form Filter (Tidak ikut tercetak) -->
    <form method="GET" action="<?php echo e(route('laporan.pemeliharaan')); ?>" class="mb-4 no-print">
        <div class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Tanggal Mulai:</label>
                <input type="date" name="tgl_mulai" class="form-control" value="<?php echo e(request('tgl_mulai')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Tanggal Akhir:</label>
                <input type="date" name="tgl_akhir" class="form-control" value="<?php echo e(request('tgl_akhir')); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-secondary w-100">Filter</button>
            </div>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-sm">
            <thead class="table-light text-center">
                <tr>
                    <th>No</th>
                    <th>Tanggal Selesai</th>
                    <th>Kode Aset</th>
                    <th>Nama Barang</th>
                    <th>Kerusakan</th>
                    <th>Tindakan Perbaikan</th>
                    <th>Biaya (Rp)</th>
                    <th>Pelapor</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td class="text-center"><?php echo e($laporan->tanggal_selesai ? \Carbon\Carbon::parse($laporan->tanggal_selesai)->format('d/m/Y') : '-'); ?></td>
                    <td><?php echo e($laporan->barang->kode_aset); ?></td>
                    <td><?php echo e($laporan->barang->merek); ?> <?php echo e($laporan->barang->jenis); ?></td>
                    <td><?php echo e(Str::limit($laporan->deskripsi_kerusakan, 30)); ?></td>
                    <td><?php echo e($laporan->tindakan_waka ?? '-'); ?></td>
                    <td class="text-end"><?php echo e($laporan->biaya_estimasi ? number_format($laporan->biaya_estimasi, 0, ',', '.') : '0'); ?></td>
                    <td><?php echo e($laporan->pelapor->name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">Tidak ada data pemeliharaan pada periode ini.</td>
                </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="6" class="text-end">Total Biaya Perbaikan:</th>
                    <th class="text-end">Rp <?php echo e(number_format($laporans->sum('biaya_estimasi'), 0, ',', '.')); ?></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>

    <div class="mt-5 row d-print-flex d-none">
        <div class="col-6 text-center">
            <p>Mengetahui,<br>Kepala Sekolah</p>
            <br><br><br>
            <p>( ___________________ )</p>
        </div>
        <div class="col-6 text-center">
            <p>Metro, <?php echo e(date('d F Y')); ?><br>Petugas Sarpras</p>
            <br><br><br>
            <p>( <?php echo e(Auth::user()->name); ?> )</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/laporan/pemeliharaan.blade.php ENDPATH**/ ?>