<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Preset Instruksi: <?php echo e($masterKodeAset->kategori); ?> - <?php echo e($masterKodeAset->jenis); ?></h5>
                <a href="<?php echo e(route('master-kode-aset.index')); ?>" class="btn btn-sm btn-light">Kembali</a>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                
                <form action="<?php echo e(route('instruksi.store', $masterKodeAset)); ?>" method="POST" class="mb-4">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" name="instruksi" class="form-control" placeholder="Tambah instruksi baru..." required>
                        <button type="submit" class="btn btn-success"><i class="fas fa-plus"></i> Tambah</button>
                    </div>
                    <?php $__errorArgs = ['instruksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">No</th>
                                <th>Instruksi</th>
                                <th width="15%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $instruksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $instruksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('instruksi.update', $instruksi)); ?>" method="POST" id="form-edit-<?php echo e($instruksi->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="text" name="instruksi" class="form-control form-control-sm" value="<?php echo e($instruksi->instruksi); ?>" required>
                                        </form>
                                    </td>
                                    <td>
                                        <button type="button" onclick="document.getElementById('form-edit-<?php echo e($instruksi->id); ?>').submit()" class="btn btn-sm btn-primary" title="Simpan Perubahan"><i class="fas fa-save"></i></button>
                                        
                                        <form action="<?php echo e(route('instruksi.destroy', $instruksi)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus instruksi ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">Belum ada preset instruksi untuk kode aset ini.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/instruksi/index.blade.php ENDPATH**/ ?>