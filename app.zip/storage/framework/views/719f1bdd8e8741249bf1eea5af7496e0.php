<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Master Kode Aset</h2>
    <a href="<?php echo e(route('master-kode-aset.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Tambah Kode Aset
    </a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead class="table-light text-center">
                    <tr>
                        <th width="5%">No</th>
                        <th>Kategori</th>
                        <th>Kelompok</th>
                        <th>Jenis</th>
                        <th>Kode Prefix</th>
                        <th>Keterangan</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $masterKodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($index + 1); ?></td>
                        <td><?php echo e($mk->kategori); ?></td>
                        <td><?php echo e($mk->kelompok); ?></td>
                        <td><?php echo e($mk->jenis); ?></td>
                        <td class="text-center"><code class="fs-6"><?php echo e($mk->kode_prefix); ?></code></td>
                        <td><?php echo e($mk->keterangan ?? '-'); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(route('instruksi.index', $mk)); ?>" class="btn btn-sm btn-info" title="Preset Instruksi">
                                <i class="fas fa-list-check"></i>
                            </a>
                            <a href="<?php echo e(route('master-kode-aset.edit', $mk)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('master-kode-aset.destroy', $mk)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada data master kode aset.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/master_kode_aset/index.blade.php ENDPATH**/ ?>