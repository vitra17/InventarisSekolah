<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Laporan Pemeliharaan Barang</h2>
    <?php if(Auth::user()->role === 'penjaga'): ?>
        <a href="<?php echo e(route('pemeliharaan.create')); ?>" class="btn btn-danger">
            <i class="fas fa-exclamation-triangle"></i> Lapor Kerusakan Baru
        </a>
    <?php endif; ?>
</div>

<!-- Filter Tab Sederhana -->
<ul class="nav nav-tabs mb-3">
    <li class="nav-item">
        <a class="nav-link <?php echo e(!request('status') ? 'active' : ''); ?>" href="<?php echo e(route('pemeliharaan.index')); ?>">Semua</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'draft' ? 'active' : ''); ?>" href="<?php echo e(route('pemeliharaan.index', ['status' => 'draft'])); ?>">Draft/Perlu Validasi</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'validated_staff' ? 'active' : ''); ?>" href="<?php echo e(route('pemeliharaan.index', ['status' => 'validated_staff'])); ?>">Menunggu Waka</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'approved_waka' ? 'active' : ''); ?>" href="<?php echo e(route('pemeliharaan.index', ['status' => 'approved_waka'])); ?>">Perlu Ditindaklanjuti</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'selesai' ? 'active' : ''); ?>" href="<?php echo e(route('pemeliharaan.index', ['status' => 'selesai'])); ?>">Selesai</a>
    </li>
</ul>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Tanggal</th>
                        <th>Kode Aset</th>
                        <th>Nama Barang</th>
                        <th>Pelapor</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($laporan->created_at->format('d/m/Y')); ?></td>
                        <td><strong><?php echo e($laporan->barang->kode_aset); ?></strong></td>
                        <td><?php echo e($laporan->barang->merek); ?> <?php echo e($laporan->barang->jenis); ?></td>
                        <td><?php echo e($laporan->pelapor->name); ?></td>
                        <td>
                            <?php
                                $badgeClass = match($laporan->status_laporan) {
                                    'draft' => 'bg-secondary',
                                    'revisi' => 'bg-warning text-dark',
                                    'validated_staff' => 'bg-info text-dark',
                                    'approved_waka' => 'bg-primary',
                                    'selesai' => 'bg-success',
                                    default => 'bg-light'
                                };
                                $statusText = match($laporan->status_laporan) {
                                    'draft' => 'Draft',
                                    'revisi' => 'Perlu Revisi',
                                    'validated_staff' => 'Menunggu Waka',
                                    'approved_waka' => 'Disetujui Waka',
                                    'selesai' => 'Selesai',
                                    default => $laporan->status_laporan
                                };
                            ?>
                            <span class="badge <?php echo e($badgeClass); ?>"><?php echo e($statusText); ?></span>
                        </td>
                        <td>
                            <!-- Detail Button -->
                            <button type="button" class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#modalDetail<?php echo e($laporan->id); ?>">
                                Lihat
                            </button>

                            <!-- AKSI BERDASARKAN ROLE & STATUS -->
                            
                            
                            <?php if(Auth::user()->role === 'penjaga' && in_array($laporan->status_laporan, ['draft', 'revisi'])): ?>
                                <a href="<?php echo e(route('pemeliharaan.edit', $laporan)); ?>" class="btn btn-sm btn-warning">Revisi/Edit</a>
                            <?php endif; ?>

                            
                            <?php if(Auth::user()->role === 'penjaga' && $laporan->status_laporan === 'approved_waka'): ?>
                                <a href="<?php echo e(route('pemeliharaan.edit', $laporan)); ?>" class="btn btn-sm btn-success">Lapor Selesai</a>
                            <?php endif; ?>

                            
                            <?php if(Auth::user()->role === 'staff' && $laporan->status_laporan === 'draft'): ?>
                                <form action="<?php echo e(route('pemeliharaan.validate.staff', $laporan)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-success">Validasi</button>
                                </form>
                                <form action="<?php echo e(route('pemeliharaan.request.revision', $laporan)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-warning" onclick="return confirm('Kirim kembali ke penjaga untuk revisi?')">Minta Revisi</button>
                                </form>
                            <?php endif; ?>

                            
                            <?php if(Auth::user()->role === 'waka' && $laporan->status_laporan === 'validated_staff'): ?>
                                <a href="<?php echo e(route('pemeliharaan.waka.instruksi.edit', $laporan)); ?>" class="btn btn-sm btn-primary">Berikan Instruksi</a>
                            <?php endif; ?>

                            
                            <?php if(Auth::user()->role === 'penjaga' && $laporan->status_laporan === 'draft' && $laporan->pelapor_id === Auth::id()): ?>
                                <form action="<?php echo e(route('pemeliharaan.destroy', $laporan)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Batalkan laporan?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>

                   

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada data laporan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($laporans->links()); ?>

    </div>
</div>


<!-- PINDAHKAN SEMUA MODAL KE SINI (DI LUAR CARD & TABLE) -->
<?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalDetail<?php echo e($laporan->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Laporan #<?php echo e($laporan->id); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Barang:</strong> <?php echo e($laporan->barang->merek); ?> <?php echo e($laporan->barang->jenis); ?></p>
                        <p><strong>Lokasi:</strong> <?php echo e($laporan->barang->lokasi->nama_ruangan); ?></p>
                        <p><strong>Deskripsi Kerusakan:</strong><br><?php echo e($laporan->deskripsi_kerusakan); ?></p>
                        <p><strong>Foto Awal:</strong><br>
                            <?php if($laporan->foto_bukti_awal): ?>
                                <img src="<?php echo e(asset('storage/' . $laporan->foto_bukti_awal)); ?>" class="img-thumbnail" style="max-height: 150px;">
                            <?php else: ?>
                                <em>Tidak ada foto</em>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <?php
                            $statusText = match($laporan->status_laporan) {
                                'draft' => 'Draft',
                                'revisi' => 'Perlu Revisi',
                                'validated_staff' => 'Menunggu Waka',
                                'approved_waka' => 'Disetujui Waka',
                                'selesai' => 'Selesai',
                                default => $laporan->status_laporan
                            };
                        ?>
                        <p><strong>Status:</strong> <?php echo e($statusText); ?></p>
                        
                        <?php if($laporan->tindakan_waka): ?>
                            <div class="alert alert-primary">
                                <strong>Instruksi Waka:</strong><br>
                                <?php echo e($laporan->tindakan_waka); ?>

                                <br><small>Estimasi Biaya: Rp <?php echo e(number_format($laporan->biaya_estimasi ?? 0, 0, ',', '.')); ?></small>
                            </div>
                        <?php endif; ?>

                        <?php if($laporan->foto_bukti_akhir): ?>
                            <p><strong>Foto Setelah Perbaikan:</strong><br>
                                <img src="<?php echo e(asset('storage/' . $laporan->foto_bukti_akhir)); ?>" class="img-thumbnail" style="max-height: 150px;">
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/pemeliharaan/index.blade.php ENDPATH**/ ?>