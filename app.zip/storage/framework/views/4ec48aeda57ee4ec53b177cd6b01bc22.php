<?php $__env->startSection('content'); ?>
<style>
    .table-laporan {
        font-size: 11px;
        border-collapse: collapse;
        width: 100%;
    }
    .table-laporan thead {
        background-color: #fff3cd;
        background-image: linear-gradient(to bottom, #fff3cd 0%, #ffeeba 100%);
    }
    .table-laporan th {
        border: 1px solid #dee2e6;
        padding: 8px 4px;
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    .table-laporan td {
        border: 1px solid #dee2e6;
        padding: 6px 4px;
        vertical-align: middle;
    }
    .table-laporan tbody tr:hover {
        background-color: #f8f9fa;
    }
    .header-laporan {
        background-color: #fff3cd;
        border: 2px solid #dee2e6;
        padding: 15px;
        margin-bottom: 20px;
        text-align: center;
    }
    .header-laporan h3 {
        margin: 0 0 10px 0;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
    }
    .info-cetak {
        font-size: 12px;
        margin: 5px 0;
    }
    .filter-section {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 5px;
        padding: 15px;
        margin-bottom: 20px;
    }
    .checkbox-col {
        width: 3%;
    }
    .no-col {
        width: 3%;
    }
    .kode-col {
        width: 12%;
    }
    .text-tiny {
        font-size: 10px;
    }
    
    /* Style Khusus Print */
    @media print {
        body * {
            visibility: hidden;
        }
        #area-cetak, #area-cetak * {
            visibility: visible;
        }
        #area-cetak {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 10px;
        }
        .no-print {
            display: none !important;
        }
        .table-laporan {
            font-size: 8pt;
            width: 100%;
        }
        .table-laporan th, 
        .table-laporan td {
            border: 1px solid black !important;
            padding: 3px;
        }
        .header-laporan {
            border: 1px solid black;
            padding: 10px;
            margin-bottom: 10px;
        }
        @page {
            size: landscape;
            margin: 1cm;
        }
    }
</style>

<div id="area-cetak">
<!-- Header Laporan -->
<div class="header-laporan">
    <h3>LAPORAN BARANG SD Muhammadiyah Metro Pusat</h3>
    <div class="info-cetak">
        <strong>Ruang:</strong> <?php echo e($lokasiTerpilih->nama_ruangan ?? 'Semua Ruangan'); ?> &nbsp;|&nbsp; 
        <strong>Dicetak pada:</strong> <?php echo e(date('d-m-Y')); ?>

        <?php if(request('tahun')): ?>
            &nbsp;|&nbsp; <strong>Tahun:</strong> <?php echo e(request('tahun')); ?>

        <?php endif; ?>
    </div>
</div>

<!-- Form Filter -->
<div class="filter-section no-print">
    <form method="GET" action="<?php echo e(route('laporan.barang')); ?>" id="filterForm">
        <div class="row align-items-end">
            <div class="col-md-3 mb-2">
                <label class="form-label fw-semibold">Filter Ruangan:</label>
                <select name="lokasi_id" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Semua Ruangan --</option>
                    <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lokasi->id); ?>" <?php echo e(request('lokasi_id') == $lokasi->id ? 'selected' : ''); ?>>
                            <?php echo e($lokasi->nama_ruangan); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2 mb-2">
                <label class="form-label fw-semibold">Filter Tahun:</label>
                <select name="tahun" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Semua Tahun --</option>
                    <?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tahun); ?>" <?php echo e(request('tahun') == $tahun ? 'selected' : ''); ?>>
                            <?php echo e($tahun); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3 mb-2">
                <label class="form-label fw-semibold">Tanggal Mulai:</label>
                <input type="date" name="tgl_mulai" class="form-control" 
                       value="<?php echo e(request('tgl_mulai')); ?>" onchange="this.form.submit()">
            </div>
            <div class="col-md-3 mb-2">
                <label class="form-label fw-semibold">Tanggal Akhir:</label>
                <input type="date" name="tgl_akhir" class="form-control" 
                       value="<?php echo e(request('tgl_akhir')); ?>" onchange="this.form.submit()">
            </div>
            <div class="col-md-1 mb-2">
                <a href="<?php echo e(route('laporan.barang')); ?>" class="btn btn-secondary w-100">
                    <i class="fas fa-redo"></i> Reset
                </a>
            </div>
        </div>
    </form>
</div>

<!-- Tombol Aksi -->
<div class="d-flex justify-content-between align-items-center mb-3 no-print">
    <h5 class="mb-0">Daftar Inventaris Barang</h5>
    <div>
        <button onclick="window.print()" class="btn btn-primary btn-sm">
            <i class="fas fa-print"></i> Cetak / Simpan PDF
        </button>
        <a href="<?php echo e(route('barang.export.excel', request()->all())); ?>" class="btn btn-success btn-sm ms-2">
            <i class="fas fa-file-excel"></i> Export Excel
        </a>
    </div>
</div>

<!-- Tabel Laporan -->
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-laporan">
                <thead>
                    <tr>
                        <th class="no-col">NO</th>
                        <th class="kode-col">LOKASI</th>
                        <th class="kode-col">KODE ASET</th>
                        <th>KATEGORI</th>
                        <th>KELOMPOK</th>
                        <th>JENIS</th>
                        <th>NAMA</th>
                        <th>KONDISI</th>
                        <th>PEROLEHAN</th>
                        <th>HARGA</th>
                        <th>TAHUN</th>
                        <th>KET</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($index + 1); ?></td>
                        <td class="text-center text-tiny">
                            <strong><?php echo e($barang->lokasi->kode_ruangan ?? '-'); ?></strong><br>
                            <?php echo e($barang->lokasi->nama_ruangan ?? ''); ?>

                        </td>
                        <td class="text-center"><strong><?php echo e($barang->kode_aset); ?></strong></td>
                        <td><?php echo e($barang->masterKodeAset->kategori ?? $barang->kategori ?? '-'); ?></td>
                        <td><?php echo e($barang->masterKodeAset->kelompok ?? '-'); ?></td>
                        <td><?php echo e($barang->masterKodeAset->jenis ?? $barang->jenis ?? '-'); ?></td>
                        <td><?php echo e($barang->nama_barang); ?></td>
                        <td class="text-center">
                            <span class="badge <?php echo e($barang->kondisi_terkini === 'Baik' ? 'bg-success' : ($barang->kondisi_terkini === 'Rusak Ringan' ? 'bg-warning' : 'bg-danger')); ?> text-tiny">
                                <?php echo e($barang->kondisi_terkini); ?>

                            </span>
                        </td>
                        <td class="text-center"><?php echo e($barang->sumber_perolehan ?? 'Beli'); ?></td>
                        <td class="text-end text-tiny">Rp <?php echo e(number_format($barang->harga_perolehan, 0, ',', '.')); ?></td>
                        <td class="text-center text-tiny"><?php echo e(\Carbon\Carbon::parse($barang->tanggal_perolehan)->format('Y')); ?></td>
                        <td class="text-tiny"><?php echo e(Str::limit($barang->sumber_dana ?? '-', 20)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="12" class="text-center">Tidak ada data barang.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="9" class="text-end">Total Harga Aset:</th>
                        <th class="text-end">Rp <?php echo e(number_format($barangs->sum('harga_perolehan'), 0, ',', '.')); ?></th>
                        <th colspan="2"></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<!-- Rekapitulasi per Kelompok & Jenis -->
<?php
    $rekapKelompok = $barangs->groupBy(function($b) {
        return $b->masterKodeAset->kelompok ?? 'Lainnya';
    })->map->count();

    $rekapJenis = $barangs->groupBy(function($b) {
        return $b->masterKodeAset->jenis ?? 'Lainnya';
    })->map->count();
?>

<?php if($barangs->count() > 0): ?>
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-light">
                <h6 class="mb-0"><strong>Rekapitulasi Jumlah per Kelompok</strong></h6>
            </div>
            <div class="card-body p-0">
                <table class="table table-bordered table-sm mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Kelompok Aset</th>
                            <th class="text-center" width="30%">Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rekapKelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelompok => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($kelompok); ?></td>
                            <td class="text-center"><?php echo e($jumlah); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr class="table-light">
                            <th>Total Keseluruhan</th>
                            <th class="text-center"><?php echo e($barangs->count()); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-light">
                <h6 class="mb-0"><strong>Rekapitulasi Jumlah per Jenis</strong></h6>
            </div>
            <div class="card-body p-0">
                <table class="table table-bordered table-sm mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Jenis Aset</th>
                            <th class="text-center" width="30%">Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rekapJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($jenis); ?></td>
                            <td class="text-center"><?php echo e($jumlah); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr class="table-light">
                            <th>Total Keseluruhan</th>
                            <th class="text-center"><?php echo e($barangs->count()); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Tanda Tangan (Hanya untuk print) -->
<div class="mt-5 row d-print-block d-none">
    <div class="col-6 text-center">
        <p>Mengetahui,<br>Kepala Sekolah</p>
        <br><br><br>
        <p>( ___________________ )</p>
    </div>
    <div class="col-6 text-center">
        <p>Metro, <?php echo e(date('d F Y')); ?><br>Petugas Inventaris</p>
        <br><br><br>
        <p>( <?php echo e(Auth::user()->name); ?> )</p>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris-sekolah\resources\views/laporan/barang.blade.php ENDPATH**/ ?>